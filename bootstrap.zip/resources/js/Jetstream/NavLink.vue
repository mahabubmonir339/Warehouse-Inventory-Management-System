<template>
  <Link :href="href" :class="classes">
    <slot></slot>
  </Link>
</template>

<script>
export default {
  props: ['href', 'active'],

  computed: {
    classes() {
      return this.active
        ? 'inline-flex items-center px-1 pt-1 border-b-2 border-indigo-400 font-medium leading-5 text-gray-900 focus:outline-hidden focus:border-indigo-700 transition duration-150 ease-in-out'
        : 'inline-flex items-center px-1 pt-1 border-b-2 border-transparent font-medium leading-5 text-gray-500 hover:text-gray-700 hover:border-gray-300 focus:outline-hidden focus:text-gray-700 focus:border-gray-300 transition duration-150 ease-in-out';
    },
  },
};
</script>
